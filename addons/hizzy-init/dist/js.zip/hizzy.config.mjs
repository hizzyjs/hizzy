export default Hizzy.defineConfig({
    static: ["assets"],
    srcFolder: "src"
});