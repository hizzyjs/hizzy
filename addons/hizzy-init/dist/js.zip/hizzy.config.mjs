export default Hizzy.defineConfig({
    static: ["assets"]
});