export default <Routes>
    <Route path="/" route="./App.jsx"/>
</Routes>;